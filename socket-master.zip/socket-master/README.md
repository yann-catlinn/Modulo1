# socket
Basado en https://devdactic.com/ionic-4-socket-io/

0) Al clonar usar:
npm install

1) Desde cero:
mkdir socket && cd socket
npm init
npm install express socket.io

2) Codificar index

3) Modificar package para heroku o similar
